"""medusa.__init__
"""

# created 2002/03/19, AMK

__revision__ = "$Id: __init__.py,v 1.2 2002/03/19 22:49:34 amk Exp $"
